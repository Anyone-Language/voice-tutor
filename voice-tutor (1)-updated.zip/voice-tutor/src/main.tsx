import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// Render the root component.  Using React.StrictMode helps to
// highlight potential problems in development.
ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// The service worker is registered automatically by the vite-plugin-pwa via
// the registerSW.js script injected into index.html.  We avoid manually
// registering a service worker here because the registration path must
// reflect the deployed base URL (e.g. /voice-tutor/) and manual registration
// could point to the wrong location on GitHub Pages.  See vite.config.ts for
// details.