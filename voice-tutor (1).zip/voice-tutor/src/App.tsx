import React, { useState, useEffect, useCallback } from 'react';
import { scenarios, Scenario, getNextStep } from './logic/conversation';
import { estimateSkillLevel } from './logic/skillDetection';
import { detectConjugationError, ConjugationResult } from './logic/conjugation';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';
import { useSpeechSynthesis } from './hooks/useSpeechSynthesis';
import { MicButton } from './components/MicButton';
import { Transcript, Message } from './components/Transcript';
import { ConjugationHelper } from './components/ConjugationHelper';
import { ChatGPTModal } from './components/ChatGPTModal';

// Main application component.  Manages state for the current conversation,
// handles user input and produces tutor replies using speech synthesis.  A
// settings panel (not implemented separately) allows the user to change
// dialect, adjust speech rate, and enable ChatGPT mode.
const App: React.FC = () => {
  // Dialect selection: default to Mexican Spanish.  Users can change this in
  // settings; here we expose a simple toggle for demonstration.
  const [dialect, setDialect] = useState<string>(() => localStorage.getItem('voiceTutor-dialect') || 'es-MX');
  const [skillLevel, setSkillLevel] = useState<1 | 2 | 3>(1);
  const [currentScenario, setCurrentScenario] = useState<Scenario | null>(null);
  const [stepIndex, setStepIndex] = useState<number>(0);
  const [messages, setMessages] = useState<Message[]>([]);
  const [responses, setResponses] = useState<string[]>([]);
  const [helper, setHelper] = useState<ConjugationResult | null>(null);
  const [awaitRepeat, setAwaitRepeat] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1);
  const [showChatGPTModal, setShowChatGPTModal] = useState<boolean>(false);
  const [apiKey, setApiKey] = useState<string>(() => localStorage.getItem('openai-key') || '');
  const [chatGPTEnabled, setChatGPTEnabled] = useState<boolean>(() => localStorage.getItem('openai-enabled') === 'true');

  // Speech hooks
  const { start, stop, listening } = useSpeechRecognition(dialect, (text, isFinal) => {
    if (isFinal) {
      handleUserResponse(text);
    }
  });
  const { speak } = useSpeechSynthesis(dialect, speechRate);

  // Initialise a new conversation when the app first loads or when the dialect
  // changes.  This picks a scenario based on the current skill level and
  // speaks the first prompt.
  useEffect(() => {
    const scenario = selectScenario(skillLevel);
    setCurrentScenario(scenario);
    setStepIndex(0);
    setMessages([{ sender: 'tutor', text: scenario.steps[0].prompt }]);
    speak(scenario.steps[0].prompt);
  }, [dialect]);

  // When the responses array grows we estimate the skill level.  The
  // estimation is updated after at least two responses but before ten to
  // prevent fluctuations later in the conversation.
  useEffect(() => {
    if (responses.length >= 2 && responses.length <= 5) {
      const level = estimateSkillLevel(responses);
      setSkillLevel(level);
    }
  }, [responses]);

  /** Select a scenario appropriate for the current dialect and skill level. */
  const selectScenario = useCallback((level: number): Scenario => {
    const candidates = scenarios.filter(s => s.dialect === dialect && s.difficulty === level);
    return candidates[Math.floor(Math.random() * candidates.length)] || scenarios[0];
  }, [dialect]);

  /** Handle a new user response. */
  const handleUserResponse = useCallback(
    async (text: string) => {
      if (!text || !currentScenario) return;
      // Append the user message to the transcript.
      setMessages(prev => [...prev, { sender: 'user', text }]);
      setResponses(prev => [...prev, text]);

      // If waiting for the user to repeat a corrected sentence
      if (awaitRepeat && helper) {
        if (text.toLowerCase().includes(helper.correctForm.toLowerCase())) {
          setHelper(null);
          setAwaitRepeat(false);
          proceed(text);
        } else {
          speak(`Intenta repetir: ${helper.correctForm}`);
        }
        return;
      }

      // Conjugation error detection
      const step = currentScenario.steps[stepIndex];
      const correction = detectConjugationError(text, step?.pronoun, step?.expectedVerb);
      if (correction) {
        // Show helper and ask the user to repeat the corrected sentence.
        setHelper(correction);
        setAwaitRepeat(true);
        speak(`${correction.corrected}. ${correction.rule} Por favor repite: ${correction.corrected}.`);
        return;
      }

      // If ChatGPT mode is enabled and a valid key is present, delegate reply.
      if (chatGPTEnabled && apiKey) {
        await handleChatGPTResponse(text);
      } else {
        proceed(text);
      }
    },
    [currentScenario, stepIndex, helper, awaitRepeat, speak, chatGPTEnabled, apiKey, proceed]
  );

  /** Proceed through the scripted scenario. */
  const proceed = useCallback(
    (text: string) => {
      if (!currentScenario) return;
      const step = currentScenario.steps[stepIndex];
      const nextIndex = getNextStep(step, text);
      if (nextIndex === undefined || nextIndex < 0 || nextIndex >= currentScenario.steps.length) {
        // End of scenario; pick a new one based on current skill level.
        const newScenario = selectScenario(skillLevel);
        setCurrentScenario(newScenario);
        setStepIndex(0);
        setMessages(prev => [...prev, { sender: 'tutor', text: newScenario.steps[0].prompt }]);
        speak(newScenario.steps[0].prompt);
      } else {
        const nextStep = currentScenario.steps[nextIndex];
        setStepIndex(nextIndex);
        setMessages(prev => [...prev, { sender: 'tutor', text: nextStep.prompt }]);
        speak(nextStep.prompt);
      }
    },
    [currentScenario, stepIndex, skillLevel, selectScenario, speak]
  );

  /** Send conversation context to OpenAI and speak the response. */
  const handleChatGPTResponse = useCallback(
    async (userText: string) => {
      // Build the chat history: map messages to OpenAI role/content pairs.
      const history = messages.map(msg => ({ role: msg.sender === 'tutor' ? 'assistant' : 'user', content: msg.text }));
      history.push({ role: 'user', content: userText });
      // System prompt to keep replies concise and aligned with dialect.
      const systemPrompt = `Eres un tutor de idiomas hablando en ${dialect}. Responde con oraciones breves y sencillas, corrigiendo sutilmente la gramática del usuario sin mencionar reglas largas.`;
      const payload = {
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          ...history
        ],
        max_tokens: 100,
        temperature: 0.7
      };
      try {
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`
          },
          body: JSON.stringify(payload)
        });
        if (!res.ok) {
          throw new Error('Respuesta de API no válida');
        }
        const data = await res.json();
        const reply = data.choices[0].message.content.trim();
        // Append tutor reply and speak it.
        setMessages(prev => [...prev, { sender: 'tutor', text: reply }]);
        speak(reply);
      } catch (err) {
        console.error(err);
        speak('Lo siento, hubo un problema con el servicio. Continuemos con los escenarios.');
        setChatGPTEnabled(false);
        proceed(userText);
      }
    },
    [messages, dialect, apiKey, speak, proceed, setChatGPTEnabled]
  );

  /** Toggle the microphone recording. */
  const handleMicClick = () => {
    if (listening) {
      stop();
    } else {
      start();
    }
  };

  /** Save the API key to local storage and enable ChatGPT. */
  const saveApiKey = (key: string) => {
    localStorage.setItem('openai-key', key);
    setApiKey(key);
    if (key) {
      setChatGPTEnabled(true);
      localStorage.setItem('openai-enabled', 'true');
    }
  };

  /** Toggle dialect between the two supported options. */
  const toggleDialect = () => {
    const newDialect = dialect === 'es-MX' ? 'es-PR' : 'es-MX';
    setDialect(newDialect);
    localStorage.setItem('voiceTutor-dialect', newDialect);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header with settings */}
      <header className="flex items-center justify-between p-4 border-b border-gray-200">
        <h1 className="text-xl font-semibold">VoiceTutor</h1>
        <div className="space-x-2">
          <button
            onClick={toggleDialect}
            className="px-3 py-1 rounded bg-secondary text-white text-sm"
          >
            {dialect === 'es-MX' ? 'Cambiar a PR' : 'Cambiar a MX'}
          </button>
          <button
            onClick={() => setShowChatGPTModal(true)}
            className="px-3 py-1 rounded bg-accent text-white text-sm"
          >
            ChatGPT
          </button>
        </div>
      </header>
      {/* Transcript display */}
      <Transcript messages={messages.slice(-12)} />
      {/* Microphone bar */}
      <div className="p-4 flex items-center justify-center border-t border-gray-200">
        <MicButton listening={listening} onPress={handleMicClick} />
        {/* Speech rate slider */}
        <div className="ml-4">
          <label className="block text-xs text-gray-600">Velocidad</label>
          <input
            type="range"
            min="0.5"
            max="1.5"
            step="0.1"
            value={speechRate}
            onChange={e => setSpeechRate(parseFloat(e.target.value))}
            className="w-32"
          />
        </div>
      </div>
      {/* Conjugation helper */}
      {helper && (
        <ConjugationHelper
          verb={helper.verb}
          pronoun={currentScenario?.steps[stepIndex]?.pronoun || ''}
          correctForm={helper.correctForm}
          rule={helper.rule}
          onClose={() => setHelper(null)}
        />
      )}
      {/* ChatGPT modal */}
      <ChatGPTModal
        visible={showChatGPTModal}
        initialKey={apiKey}
        onClose={() => setShowChatGPTModal(false)}
        onSave={saveApiKey}
      />
    </div>
  );
};

export default App;