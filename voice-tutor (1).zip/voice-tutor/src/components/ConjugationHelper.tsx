import React from 'react';

interface ConjugationHelperProps {
  verb: string;
  pronoun: string;
  correctForm: string;
  rule: string;
  onClose: () => void;
}

/**
 * Shows a small helper card when a conjugation error is detected.  It
 * displays the infinitive, the pronoun and the correct form along with a
 * short rule.  The helper can be dismissed by the user.
 */
export const ConjugationHelper: React.FC<ConjugationHelperProps> = ({ verb, pronoun, correctForm, rule, onClose }) => {
  return (
    <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-white border border-gray-300 shadow-lg rounded-lg p-4 max-w-sm z-50">
      <div className="flex justify-between items-center mb-2">
        <span className="font-semibold">Ayuda de conjugación</span>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-700" aria-label="Cerrar ayuda">×</button>
      </div>
      <p className="text-sm mb-1"><strong>Verbo:</strong> {verb}</p>
      <p className="text-sm mb-1"><strong>Pronombre:</strong> {pronoun}</p>
      <p className="text-sm mb-2"><strong>Forma correcta:</strong> {correctForm}</p>
      <p className="text-xs text-gray-600">{rule}</p>
    </div>
  );
};