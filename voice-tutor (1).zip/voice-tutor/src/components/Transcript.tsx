import React from 'react';

export interface Message {
  sender: 'tutor' | 'user';
  text: string;
}

interface TranscriptProps {
  messages: Message[];
}

/**
 * A simple component to display the conversation transcript.  Messages
 * from the tutor are rendered on the left in the primary colour while
 * user messages are rendered on the right in a neutral colour.  The
 * container scrolls when content exceeds its height.
 */
export const Transcript: React.FC<TranscriptProps> = ({ messages }) => {
  return (
    <div className="flex-1 overflow-y-auto space-y-2 p-4">
      {messages.map((msg, idx) => {
        const isTutor = msg.sender === 'tutor';
        const bubbleClasses = isTutor
          ? 'bg-primary text-white self-start'
          : 'bg-gray-100 text-gray-900 self-end';
        return (
          <div
            key={idx}
            className={`max-w-xs p-3 rounded-lg shadow-sm ${bubbleClasses}`}
          >
            {msg.text}
          </div>
        );
      })}
    </div>
  );
};