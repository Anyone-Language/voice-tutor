import React, { useState } from 'react';

interface ChatGPTModalProps {
  visible: boolean;
  initialKey: string;
  onClose: () => void;
  onSave: (key: string) => void;
}

/**
 * Modal dialog that allows the user to paste their own OpenAI API key.  The key
 * is stored locally and never transmitted anywhere except to the OpenAI API
 * when making requests.  The modal explains that supplying a key is optional.
 */
export const ChatGPTModal: React.FC<ChatGPTModalProps> = ({ visible, initialKey, onClose, onSave }) => {
  const [key, setKey] = useState<string>(initialKey);
  if (!visible) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-lg p-6 max-w-md w-full">
        <h2 className="text-xl font-semibold mb-4">Open Conversation Mode</h2>
        <p className="text-sm mb-4">
          Introduce tu clave de API de OpenAI para activar la conversación abierta. La clave se
          guardará solamente en tu dispositivo. Este paso es opcional; si no lo haces, la
          aplicación seguirá funcionando con escenarios guiados.
        </p>
        <textarea
          className="w-full border border-gray-300 rounded p-2 mb-4"
          rows={3}
          value={key}
          placeholder="sk-..."
          onChange={e => setKey(e.target.value.trim())}
        ></textarea>
        <div className="flex justify-end space-x-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded bg-gray-200 text-gray-700 hover:bg-gray-300"
          >
            Cancelar
          </button>
          <button
            onClick={() => {
              onSave(key);
              onClose();
            }}
            className="px-4 py-2 rounded bg-primary text-white hover:bg-green-600"
          >
            Guardar clave
          </button>
        </div>
      </div>
    </div>
  );
};