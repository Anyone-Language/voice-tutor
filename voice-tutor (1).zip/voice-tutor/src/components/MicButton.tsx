import React from 'react';
import { FaMicrophone, FaMicrophoneSlash } from 'react-icons/fa';

interface MicButtonProps {
  listening: boolean;
  onPress: () => void;
}

/**
 * A large circular microphone button.  Displays a filled microphone when
 * listening and an outline when idle.  Clicking the button toggles the
 * listening state.  Uses icons from react-icons; if those are not
 * available at runtime the fallback is a simple Unicode microphone.
 */
export const MicButton: React.FC<MicButtonProps> = ({ listening, onPress }) => {
  return (
    <button
      aria-label="Pulsar para hablar"
      onClick={onPress}
      className={`rounded-full w-24 h-24 flex items-center justify-center shadow-md transition-colors duration-200 ${
        listening ? 'bg-primary text-white' : 'bg-white text-primary border-2 border-primary'
      }`}
    >
      {listening ? <FaMicrophoneSlash size={32} /> : <FaMicrophone size={32} />}
    </button>
  );
};