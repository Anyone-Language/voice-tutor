// Simple heuristics for estimating the learner's skill level based on early
// responses.  The algorithm computes basic statistics like vocabulary size
// (number of unique words), average sentence length and whether verbs are
// used.  This is intentionally lightweight and non‑deterministic; its goal
// is merely to choose an appropriate scenario difficulty.

/**
 * Estimate the difficulty level (1 = beginner, 2 = intermediate, 3 = advanced)
 * from the first few responses.  Unique word count is used as the primary
 * signal.  Sentence connectors and common verbs raise the level.  The
 * thresholds are empirical and can be tuned.
 */
export function estimateSkillLevel(responses: string[]): 1 | 2 | 3 {
  let words: string[] = [];
  let verbCount = 0;
  const connectors = ['que', 'porque', 'cuando', 'aunque', 'pero'];
  const commonVerbs = ['ser', 'estar', 'tener', 'hacer', 'ir', 'decir', 'poder', 'ver', 'dar', 'saber'];
  let connectorCount = 0;
  for (const resp of responses) {
    const tokens = resp.toLowerCase().split(/\s+/).map(t => t.replace(/[^a-záéíóúñü]+/g, ''));
    words.push(...tokens.filter(Boolean));
    for (const token of tokens) {
      if (connectors.includes(token)) connectorCount++;
      if (commonVerbs.includes(token)) verbCount++;
    }
  }
  const uniqueWords = new Set(words).size;
  // Basic heuristic: more unique words and connectors/verbs indicate higher level.
  if (uniqueWords < 10 && connectorCount === 0) {
    return 1;
  }
  if (uniqueWords < 20 && verbCount < 5) {
    return 2;
  }
  return 3;
}