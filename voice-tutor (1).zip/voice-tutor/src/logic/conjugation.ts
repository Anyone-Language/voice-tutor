// Basic conjugation helper and error detector.  This module contains a
// small subset of Spanish verbs and their present tense conjugations.  The
// detection algorithm looks for infinitive verbs in the user’s response and
// suggests the correct form for the given pronoun.

export interface ConjugationResult {
  corrected: string;
  verb: string;
  correctForm: string;
  rule: string;
}

// Present tense conjugations for a handful of common verbs.  Each verb maps
// pronouns to the appropriate conjugated form.  Only verbs likely to appear
// in our scenarios are included.  Additional verbs can be added as needed.
const conjugations: Record<string, Record<string, string>> = {
  hablar: { yo: 'hablo', tú: 'hablas', él: 'habla', nosotros: 'hablamos', ustedes: 'hablan' },
  comer: { yo: 'como', tú: 'comes', él: 'come', nosotros: 'comemos', ustedes: 'comen' },
  vivir: { yo: 'vivo', tú: 'vives', él: 'vive', nosotros: 'vivimos', ustedes: 'viven' },
  ser: { yo: 'soy', tú: 'eres', él: 'es', nosotros: 'somos', ustedes: 'son' },
  estar: { yo: 'estoy', tú: 'estás', él: 'está', nosotros: 'estamos', ustedes: 'están' },
  tener: { yo: 'tengo', tú: 'tienes', él: 'tiene', nosotros: 'tenemos', ustedes: 'tienen' },
  hacer: { yo: 'hago', tú: 'haces', él: 'hace', nosotros: 'hacemos', ustedes: 'hacen' },
  ir: { yo: 'voy', tú: 'vas', él: 'va', nosotros: 'vamos', ustedes: 'van' },
  gustar: { yo: 'me gusta', tú: 'te gusta', él: 'le gusta', nosotros: 'nos gusta', ustedes: 'les gusta' },
  pedir: { yo: 'pido', tú: 'pides', él: 'pide', nosotros: 'pedimos', ustedes: 'piden' },
  beber: { yo: 'bebo', tú: 'bebes', él: 'bebe', nosotros: 'bebemos', ustedes: 'beben' },
  entender: { yo: 'entiendo', tú: 'entiendes', él: 'entiende', nosotros: 'entendemos', ustedes: 'entienden' },
  despertarse: { yo: 'me despierto', tú: 'te despiertas', él: 'se despierta', nosotros: 'nos despertamos', ustedes: 'se despiertan' },
  desayunar: { yo: 'desayuno', tú: 'desayunas', él: 'desayuna', nosotros: 'desayunamos', ustedes: 'desayunan' },
  acostarse: { yo: 'me acuesto', tú: 'te acuestas', él: 'se acuesta', nosotros: 'nos acostamos', ustedes: 'se acuestan' },
  // Reflexive verb "levantarse" used in daily life scenarios.
  levantarse: { yo: 'me levanto', tú: 'te levantas', él: 'se levanta', nosotros: 'nos levantamos', ustedes: 'se levantan' },
  // Non‑reflexive levantar forms (rarely used in this app) are defined separately.
  levantar: { yo: 'levanto', tú: 'levantas', él: 'levanta', nosotros: 'levantamos', ustedes: 'levantan' }
};

/**
 * Detect whether the user used an infinitive instead of the correct conjugated
 * form.  If an error is found, return a correction object; otherwise
 * undefined.  The pronoun parameter is one of the Spanish subject pronouns as
 * used in the conjugations table.  When the verb is gustar the pronoun is
 * treated specially because the construction uses indirect objects (me/te/le...).
 */
export function detectConjugationError(
  sentence: string,
  pronoun?: string,
  expectedVerb?: string
): ConjugationResult | undefined {
  if (!pronoun || !expectedVerb) return undefined;
  const forms = conjugations[expectedVerb];
  if (!forms) return undefined;
  const lowered = sentence.toLowerCase();
  // If the sentence already contains the correct form, do nothing.
  if (lowered.includes(forms[pronoun])) {
    return undefined;
  }
  // If the infinitive appears but not the conjugated form, suggest a correction.
  if (lowered.includes(expectedVerb)) {
    const corrected = sentence.replace(new RegExp(expectedVerb, 'i'), forms[pronoun]);
    const rule = `Para el verbo '${expectedVerb}' en presente con el pronombre '${pronoun}' se usa '${forms[pronoun]}'.`;
    return {
      corrected,
      verb: expectedVerb,
      correctForm: forms[pronoun],
      rule
    };
  }
  return undefined;
}