// This module defines the scripted conversation scenarios and helper functions
// for matching user responses.  Scenarios are used in the free (non‑AI)
// conversation mode.

export type Difficulty = 1 | 2 | 3;

export interface ResponseOption {
  /** Patterns to match against the user response. */
  patterns: string[];
  /** Index of the next step. */
  next: number;
}

export interface Step {
  /** Prompt the tutor will speak. */
  prompt: string;
  /** Response options with patterns and next step indices. */
  responses: ResponseOption[];
  /** Pronoun for conjugation detection (yo, tú, él/ella, nosotros, ustedes). */
  pronoun?: string;
  /** Expected verb in infinitive for conjugation correction. */
  expectedVerb?: string;
  /** Fallback next step if no patterns match. */
  defaultNext?: number;
}

export interface Scenario {
  id: string;
  title: string;
  dialect: string;
  difficulty: Difficulty;
  steps: Step[];
}

/**
 * Strip accents/diacritics from a string.  Uses Unicode normalization and
 * removes combining marks (U+0300–U+036F).  This ensures patterns match
 * regardless of accent marks.
 */
function stripAccents(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

/**
 * Levenshtein distance implementation used for fuzzy matching.
 */
function levenshtein(a: string, b: string): number {
  const matrix: number[][] = [];
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  return matrix[b.length][a.length];
}

/**
 * Test whether a user response matches a given pattern using substring
 * containment or edit distance threshold.
 */
function fuzzyMatch(response: string, pattern: string): boolean {
  const resp = stripAccents(response);
  const pat = stripAccents(pattern);
  if (resp.includes(pat)) return true;
  const dist = levenshtein(resp, pat);
  const threshold = Math.floor(pat.length * 0.4);
  return dist <= threshold;
}

/** Determine the next step index given a step definition and the user's
 * response.  Returns undefined if the scenario should end.
 */
export function getNextStep(step: Step, response: string): number | undefined {
  for (const opt of step.responses) {
    for (const pattern of opt.patterns) {
      if (fuzzyMatch(response, pattern)) {
        return opt.next;
      }
    }
  }
  return step.defaultNext;
}

// Scenario definitions will be appended below.  We split them out into
// separate declarations to keep patch size manageable.

export const scenarios: Scenario[] = [];

// Mexican Spanish conversation scenarios.
const scenariosMx: Scenario[] = [
  {
    id: 'greetings',
    title: 'Saludos',
    dialect: 'es-MX',
    difficulty: 1,
    steps: [
      {
        prompt: 'Hola, ¿cómo estás?',
        responses: [
          { patterns: ['bien', 'muy bien', 'estoy bien'], next: 1 },
          { patterns: ['mal', 'más o menos', 'no muy bien'], next: 1 }
        ],
        pronoun: 'tú'
      },
      {
        prompt: '¿De dónde eres?',
        responses: [
          { patterns: ['soy de', 'vengo de'], next: 2 },
          { patterns: ['mexico', 'méxico'], next: 2 },
          { patterns: ['puerto rico', 'argentina', 'españa'], next: 2 }
        ],
        pronoun: 'tú',
        defaultNext: 2
      },
      {
        prompt: 'Mucho gusto. ¿Qué te gusta hacer en tu tiempo libre?',
        responses: [
          { patterns: ['leer', 'leer libros', 'leer mucho'], next: 3 },
          { patterns: ['correr', 'hacer ejercicio'], next: 3 },
          { patterns: ['ver películas', 'ver pelis', 'ver series'], next: 3 },
          { patterns: ['viajar'], next: 3 }
        ],
        pronoun: 'tú',
        expectedVerb: 'gustar',
        defaultNext: 3
      },
      {
        prompt: '¿Quieres hablar de comida o de viajes?',
        responses: [
          { patterns: ['comida', 'comer'], next: 4 },
          { patterns: ['viaje', 'viajes'], next: 5 }
        ],
        pronoun: 'tú',
        defaultNext: 4
      },
      {
        prompt: 'Muy bien, vamos a hablar de comida. ¿Cuál es tu platillo favorito?',
        responses: [
          { patterns: ['tacos', 'enchiladas', 'mole', 'chiles'], next: 6 },
          { patterns: ['no tengo', 'ninguno'], next: 6 }
        ],
        pronoun: 'tú',
        expectedVerb: 'ser',
        defaultNext: 6
      },
      {
        prompt: 'Perfecto, hablemos de viajes. ¿Qué país quieres visitar?',
        responses: [
          { patterns: ['méxico', 'españa', 'francia'], next: 6 },
          { patterns: ['japón', 'italia', 'argentina'], next: 6 }
        ],
        pronoun: 'tú',
        defaultNext: 6
      },
      {
        prompt: '¡Gracias por compartir! Continuemos la conversación...',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  },
  {
    id: 'small-talk',
    title: 'Pequeña charla',
    dialect: 'es-MX',
    difficulty: 2,
    steps: [
      {
        prompt: '¿Qué hiciste este fin de semana?',
        responses: [
          { patterns: ['fui', 'salí', 'viajé', 'estuve'], next: 1 },
          { patterns: ['nada', 'descansé', 'dormí'], next: 1 }
        ],
        pronoun: 'tú',
        expectedVerb: 'hacer',
        defaultNext: 1
      },
      {
        prompt: '¿Tienes hermanos o hermanas?',
        responses: [
          { patterns: ['sí', 'tengo', 'muchos'], next: 2 },
          { patterns: ['no', 'ninguno'], next: 2 }
        ],
        pronoun: 'tú',
        expectedVerb: 'tener',
        defaultNext: 2
      },
      {
        prompt: '¿Qué tipo de música te gusta?',
        responses: [
          { patterns: ['rock', 'pop', 'salsa', 'reggaeton'], next: 3 },
          { patterns: ['clásica', 'ninguna'], next: 3 }
        ],
        pronoun: 'tú',
        expectedVerb: 'gustar',
        defaultNext: 3
      },
      {
        prompt: '¡Genial! Gracias por compartir.',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  },
  {
    id: 'ordering-food',
    title: 'Pedir comida',
    dialect: 'es-MX',
    difficulty: 2,
    steps: [
      {
        prompt: 'Hola, ¿qué te gustaría pedir?',
        responses: [
          { patterns: ['quiero', 'me gustaría', 'voy a pedir'], next: 1 }
        ],
        pronoun: 'yo',
        expectedVerb: 'pedir',
        defaultNext: 1
      },
      {
        prompt: '¿Y para beber?',
        responses: [
          { patterns: ['agua', 'refresco', 'jugo', 'cerveza'], next: 2 }
        ],
        pronoun: 'yo',
        expectedVerb: 'beber',
        defaultNext: 2
      },
      {
        prompt: '¿Algo más?',
        responses: [
          { patterns: ['no', 'eso es todo', 'nada'], next: 3 },
          { patterns: ['sí', 'postre'], next: 3 }
        ],
        pronoun: 'tú',
        defaultNext: 3
      },
      {
        prompt: 'Buen provecho. ¿Te gusta la comida mexicana?',
        responses: [
          { patterns: ['sí', 'me encanta', 'mucho'], next: 4 },
          { patterns: ['no', 'poco'], next: 4 }
        ],
        pronoun: 'te',
        expectedVerb: 'gustar',
        defaultNext: 4
      },
      {
        prompt: '¡Perfecto! Continuemos...',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  },
  {
    id: 'directions',
    title: 'Direcciones',
    dialect: 'es-MX',
    difficulty: 3,
    steps: [
      {
        prompt: '¿Adónde vas?',
        responses: [
          { patterns: ['al centro', 'a la escuela', 'a casa'], next: 1 }
        ],
        pronoun: 'tú',
        expectedVerb: 'ir',
        defaultNext: 1
      },
      {
        prompt: 'Sigue derecho y luego gira a la izquierda. ¿Entendiste?',
        responses: [
          { patterns: ['sí', 'entendí', 'claro'], next: 2 },
          { patterns: ['no', 'repite'], next: 0 }
        ],
        pronoun: 'tú',
        expectedVerb: 'entender',
        defaultNext: 2
      },
      {
        prompt: 'Excelente. ¡Buen viaje!',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  },
  {
    id: 'daily-life',
    title: 'Vida diaria',
    dialect: 'es-MX',
    difficulty: 3,
    steps: [
      {
        prompt: '¿Cómo es un día típico para ti?',
        responses: [
          { patterns: ['trabajo', 'estudio', 'voy'], next: 1 }
        ],
        pronoun: 'tú',
        expectedVerb: 'ser',
        defaultNext: 1
      },
      {
        prompt: '¿A qué hora te despiertas?',
        responses: [
          { patterns: ['a las', 'me levanto'], next: 2 }
        ],
        pronoun: 'tú',
        expectedVerb: 'despertarse',
        defaultNext: 2
      },
      {
        prompt: '¿Qué desayunas normalmente?',
        responses: [
          { patterns: ['huevos', 'pan', 'café', 'nada'], next: 3 }
        ],
        pronoun: 'tú',
        expectedVerb: 'desayunar',
        defaultNext: 3
      },
      {
        prompt: '¿A qué hora te acuestas?',
        responses: [
          { patterns: ['a las', 'tarde', 'temprano'], next: 4 }
        ],
        pronoun: 'tú',
        expectedVerb: 'acostarse',
        defaultNext: 4
      },
      {
        prompt: 'Gracias por contarme sobre tu día.',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  }
];

// Puerto Rican Spanish conversation scenarios.
const scenariosPr: Scenario[] = [
  {
    id: 'greetings-pr',
    title: 'Saludos boricuas',
    dialect: 'es-PR',
    difficulty: 1,
    steps: [
      {
        prompt: '¿Qué es la que hay?',
        responses: [
          { patterns: ['todo bien', 'todo chévere', 'bien'], next: 1 },
          { patterns: ['mal', 'más o menos'], next: 1 }
        ],
        pronoun: 'tú'
      },
      {
        prompt: '¿De dónde eres?',
        responses: [
          { patterns: ['soy de', 'vengo de'], next: 2 },
          { patterns: ['puerto rico', 'la isla'], next: 2 }
        ],
        pronoun: 'tú',
        defaultNext: 2
      },
      {
        prompt: '¿Qué te gusta hacer en tu tiempo libre?',
        responses: [
          { patterns: ['ir a la playa', 'salir con amistades'], next: 3 },
          { patterns: ['dormir', 'ver televisión'], next: 3 }
        ],
        pronoun: 'tú',
        expectedVerb: 'gustar',
        defaultNext: 3
      },
      {
        prompt: '¿Quieres hablar de comida criolla o de viajes?',
        responses: [
          { patterns: ['comida', 'mofongo', 'pasteles'], next: 4 },
          { patterns: ['viajes', 'turismo'], next: 5 }
        ],
        pronoun: 'tú',
        defaultNext: 4
      },
      {
        prompt: 'Perfecto, ¿cuál es tu plato criollo favorito?',
        responses: [
          { patterns: ['mofongo', 'arroz con gandules', 'lechón'], next: 6 },
          { patterns: ['no tengo', 'ninguno'], next: 6 }
        ],
        pronoun: 'tú',
        expectedVerb: 'ser',
        defaultNext: 6
      },
      {
        prompt: '¿Qué lugar quieres visitar en el Caribe?',
        responses: [
          { patterns: ['república dominicana', 'cuba', 'jamaica'], next: 6 },
          { patterns: ['aruba', 'curaçao'], next: 6 }
        ],
        pronoun: 'tú',
        defaultNext: 6
      },
      {
        prompt: '¡Qué nítido! Continuemos...',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  },
  {
    id: 'small-talk-pr',
    title: 'Pequeña charla PR',
    dialect: 'es-PR',
    difficulty: 2,
    steps: [
      {
        prompt: '¿Qué hiciste este weekend?',
        responses: [
          { patterns: ['fui', 'salí', 'janguié'], next: 1 },
          { patterns: ['nada', 'dormí'], next: 1 }
        ],
        pronoun: 'tú',
        expectedVerb: 'hacer',
        defaultNext: 1
      },
      {
        prompt: '¿Tienes hermanos o hermanas?',
        responses: [
          { patterns: ['sí', 'tengo'], next: 2 },
          { patterns: ['no', 'ninguno'], next: 2 }
        ],
        pronoun: 'tú',
        expectedVerb: 'tener',
        defaultNext: 2
      },
      {
        prompt: '¿Qué tipo de música te gusta?',
        responses: [
          { patterns: ['salsa', 'reggaetón', 'bomba', 'plena'], next: 3 },
          { patterns: ['rock', 'pop', 'ninguna'], next: 3 }
        ],
        pronoun: 'tú',
        expectedVerb: 'gustar',
        defaultNext: 3
      },
      {
        prompt: '¡Brutal! Gracias por compartir.',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  },
  {
    id: 'ordering-food-pr',
    title: 'Pedir comida PR',
    dialect: 'es-PR',
    difficulty: 2,
    steps: [
      {
        prompt: 'Buenas, ¿qué te gustaría comer?',
        responses: [
          { patterns: ['quiero', 'me gustaría', 'voy a pedir'], next: 1 }
        ],
        pronoun: 'yo',
        expectedVerb: 'comer',
        defaultNext: 1
      },
      {
        prompt: '¿Y para tomar?',
        responses: [
          { patterns: ['agua', 'refresco', 'jugo', 'cerveza'], next: 2 }
        ],
        pronoun: 'yo',
        expectedVerb: 'beber',
        defaultNext: 2
      },
      {
        prompt: '¿Deseas postre?',
        responses: [
          { patterns: ['sí', 'claro', 'flan'], next: 3 },
          { patterns: ['no', 'gracias'], next: 3 }
        ],
        pronoun: 'tú',
        defaultNext: 3
      },
      {
        prompt: 'Buen provecho. ¿Te gusta la comida criolla?',
        responses: [
          { patterns: ['sí', 'me encanta', 'mucho'], next: 4 },
          { patterns: ['no', 'poco'], next: 4 }
        ],
        pronoun: 'te',
        expectedVerb: 'gustar',
        defaultNext: 4
      },
      {
        prompt: '¡Buenísimo! Continuemos...',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  },
  {
    id: 'directions-pr',
    title: 'Direcciones PR',
    dialect: 'es-PR',
    difficulty: 3,
    steps: [
      {
        prompt: '¿Pa\' dónde vas?',
        responses: [
          { patterns: ['pa\' la playa', 'pa\' el trabajo', 'pa\' casa'], next: 1 }
        ],
        pronoun: 'tú',
        expectedVerb: 'ir',
        defaultNext: 1
      },
      {
        prompt: 'Sigue recto y luego dobla a la izquierda. ¿Entendiste?',
        responses: [
          { patterns: ['sí', 'entendí', 'dale'], next: 2 },
          { patterns: ['no', 'repite'], next: 0 }
        ],
        pronoun: 'tú',
        expectedVerb: 'entender',
        defaultNext: 2
      },
      {
        prompt: '¡Super! Que te vaya bien.',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  },
  {
    id: 'daily-life-pr',
    title: 'Vida diaria PR',
    dialect: 'es-PR',
    difficulty: 3,
    steps: [
      {
        prompt: '¿Cómo es un día típico para ti?',
        responses: [
          { patterns: ['trabajo', 'estudio', 'jangueo'], next: 1 }
        ],
        pronoun: 'tú',
        expectedVerb: 'ser',
        defaultNext: 1
      },
      {
        prompt: '¿A qué hora te levantas?',
        responses: [
          { patterns: ['a las', 'me levanto'], next: 2 }
        ],
        pronoun: 'tú',
        expectedVerb: 'levantarse',
        defaultNext: 2
      },
      {
        prompt: '¿Qué desayunas normalmente?',
        responses: [
          { patterns: ['café', 'tostadas', 'nada'], next: 3 }
        ],
        pronoun: 'tú',
        expectedVerb: 'desayunar',
        defaultNext: 3
      },
      {
        prompt: '¿A qué hora te acuestas?',
        responses: [
          { patterns: ['a las', 'tarde', 'temprano'], next: 4 }
        ],
        pronoun: 'tú',
        expectedVerb: 'acostarse',
        defaultNext: 4
      },
      {
        prompt: '¡Gracias por contarme sobre tu día!',
        responses: [],
        pronoun: 'tú',
        defaultNext: undefined
      }
    ]
  }
];

// Push all scenarios into the exported array.
scenarios.push(...scenariosMx, ...scenariosPr);