import { useState, useEffect } from 'react';

/**
 * Hook wrapping the Web Speech API's speech synthesis.  It enumerates available
 * voices and chooses an appropriate voice for the provided language.  When
 * speaking text, it applies the configured speech rate and selected voice.
 */
export function useSpeechSynthesis(lang: string, rate: number) {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    const synth = window.speechSynthesis;
    // Load voices asynchronously; some browsers dispatch the voiceschanged event.
    function loadVoices() {
      const list = synth.getVoices();
      if (list.length > 0) {
        setVoices(list);
      }
    }
    loadVoices();
    synth.onvoiceschanged = loadVoices;
  }, []);

  /**
   * Choose a voice that best matches the language.  Prefers exact match, then
   * base language match (e.g. es), then any voice.
   */
  function selectVoice() {
    if (voices.length === 0) return undefined;
    const exact = voices.find(v => v.lang === lang);
    if (exact) return exact;
    const base = voices.find(v => v.lang.split('-')[0] === lang.split('-')[0]);
    if (base) return base;
    return voices[0];
  }

  /**
   * Speak the provided text immediately.  If the synthesiser is currently
   * speaking it will cancel the previous utterance before starting the next.
   */
  function speak(text: string) {
    const synth = window.speechSynthesis;
    synth.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voice = selectVoice();
    if (voice) {
      utterance.voice = voice;
    }
    utterance.rate = rate;
    synth.speak(utterance);
  }

  return { voices, speak };
}