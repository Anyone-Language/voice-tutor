import { useEffect, useState, useRef, useCallback } from 'react';

/**
 * Hook to encapsulate the Web Speech API's SpeechRecognition interface.
 *
 * @param lang BCP‑47 language tag (e.g. 'es-MX').
 * @param onResult Callback invoked with the transcript and whether the result is final.
 */
export function useSpeechRecognition(
  lang: string,
  onResult: (transcript: string, isFinal: boolean, confidence?: number) => void
) {
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const [listening, setListening] = useState(false);

  // Initialise the recognition object on mount and whenever the language changes.
  useEffect(() => {
    const SpeechRecognitionConstructor: typeof SpeechRecognition | undefined =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognitionConstructor) {
      console.warn('SpeechRecognition is not supported in this browser');
      return;
    }
    const recognition = new SpeechRecognitionConstructor();
    recognition.lang = lang;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let transcript = '';
      let isFinal = false;
      let confidence: number | undefined;
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        transcript += result[0].transcript;
        if (result.isFinal) {
          isFinal = true;
          confidence = result[0].confidence;
        }
      }
      onResult(transcript.trim(), isFinal, confidence);
    };
    recognition.onend = () => {
      setListening(false);
    };
    recognition.onerror = () => {
      setListening(false);
    };
    recognitionRef.current = recognition;
  }, [lang, onResult]);

  // Start listening for speech.  If the API throws because a start call is
  // already in progress we silently swallow the error.
  const start = useCallback(() => {
    const recogniser = recognitionRef.current;
    if (recogniser && !listening) {
      try {
        recogniser.start();
        setListening(true);
      } catch (err) {
        console.error('Failed to start recognition:', err);
      }
    }
  }, [listening]);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
  }, []);

  return { start, stop, listening };
}