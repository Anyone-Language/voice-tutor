// Minimal service worker for VoiceTutor.
//
// This script caches the application shell so that VoiceTutor can load
// instantly when offline.  When a fetch request is made the service
// worker looks for a cached response before going to the network.  If
// the user is offline and a navigation request is made, the cached
// index.html will be served as a fallback.

const CACHE_NAME = 'voice-tutor-v1';
const PRECACHE_URLS = [
  '/voice-tutor/',
  '/voice-tutor/index.html',
  '/voice-tutor/manifest.webmanifest'
];

self.addEventListener('install', event => {
  // Precache the application shell.
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE_URLS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  // Clean up any old caches.
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const { request } = event;
  // Only handle GET requests.
  if (request.method !== 'GET') return;
  event.respondWith(
    caches.match(request).then(cached => {
      if (cached) {
        return cached;
      }
      return fetch(request).then(response => {
        // Cache the response for future visits.
        const respClone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, respClone));
        return response;
      }).catch(() => {
        // If offline and navigating to a page, serve the shell.
        if (request.mode === 'navigate') {
          return caches.match('/voice-tutor/index.html');
        }
      });
    })
  );
});