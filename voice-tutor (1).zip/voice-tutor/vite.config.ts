import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

// Vite configuration enables React support and adds PWA capabilities.  The PWA
// plugin generates a service worker and manifest at build time so that the
// application can be installed on iOS, Android and desktop.  This
// configuration uses the auto update strategy, which will check for updated
// service worker versions and apply them in the background.  See the README
// for more details.

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/maskable-icon.png'],
      manifest: {
        name: 'VoiceTutor',
        short_name: 'VoiceTutor',
        description: 'Voice to voice language learning PWA',
        start_url: '/',
        scope: '/',
        display: 'standalone',
        background_color: '#ffffff',
        theme_color: '#48bb78',
        icons: [
          {
            src: 'icons/icon-192.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: 'icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png'
          },
          {
            src: 'icons/maskable-icon.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable'
          }
        ]
      }
    })
  ],
  server: {
    port: 5173,
    open: true
  }
});