/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        primary: '#48bb78', // green tone for main brand colour
        secondary: '#2f855a',
        accent: '#f6ad55'   // orange for highlights
      }
    }
  },
  plugins: []
};