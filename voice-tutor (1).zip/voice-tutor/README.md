# VoiceTutor

**VoiceTutor** is a free, voice‑first progressive web application (PWA) that helps you learn to speak and understand a foreign language by talking with your browser.  The app feels like a call with a friendly tutor — you press the microphone, speak naturally and the tutor answers back with spoken replies.  There are no flash cards, no menus of exercises and no artificial barriers: just a conversation that adapts to your level and gently nudges you forward.

The application runs entirely in the browser.  It uses the [Web Speech API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API) for speech recognition and synthesis.  The API exposes two components: `SpeechRecognition`, which listens for audio and produces transcripts, and `SpeechSynthesis`, which speaks text back to the user.  The MDN documentation notes that the API “has two parts: `SpeechSynthesis` (Text‑to‑Speech) and `SpeechRecognition` (Asynchronous Speech Recognition)”【290950699775772†L174-L205】.  VoiceTutor combines these interfaces to create a seamless voice‑only experience.

VoiceTutor is a full PWA and can be installed on iOS, Android and desktop.  The service worker caches the app shell, so the core user interface is available offline.  Caching is central to PWAs: storing HTML, JavaScript, CSS and images locally allows the app to load instantly and continue working without network connectivity.  MDN explains that caching provides two main benefits: offline operation and responsiveness【13274724675032†L174-L190】.  VoiceTutor pre‑caches its static assets and dynamically caches API responses when using ChatGPT mode.

## Features

### Voice‑First Experience

* **Speak and listen, don’t study.**  The app revolves around a large push‑to‑talk microphone button.  You press the button, speak your answer and release; the tutor replies with synthesized speech.  A live transcript of your utterance is shown for clarity.
* **Automatic skill detection.**  From your first few responses the app measures vocabulary size, sentence complexity and verb usage to estimate your level.  It then selects appropriate conversation scenarios and continues to adjust as you improve.
* **Built‑in correction and conjugation helper.**  When a conjugation error is detected the tutor will (1) speak the corrected sentence naturally, (2) give one short rule in your native language, and (3) ask you to repeat the sentence aloud.  A small helper panel displays the verb infinitive and correct form for the subject.
* **Dialect and accent awareness.**  At launch you can choose Spanish (Mexico – `es‑MX`) or Spanish (Puerto Rico – `es‑PR`).  Each dialect comes with its own vocabulary, phrasing and examples.  The app automatically selects the most natural device voice available for the target language.
* **Adaptive content.**  Conversation scenarios cover greetings, small talk, ordering food, asking for directions and daily life.  Scenarios are tagged with difficulty levels; the skill detector chooses which scenario to play next.  Multiple valid answers (synonyms, fuzzy matching, minor variations) are accepted to keep the conversation flowing.
* **Free and privacy‑respectful.**  VoiceTutor runs entirely in your browser.  It does not send your microphone audio anywhere, and it does not store any data on a server.  Optional ChatGPT mode can be enabled by supplying your own OpenAI key; the key is stored in local storage only and never leaves your device.

### Optional ChatGPT Mode

VoiceTutor includes an optional “Open Conversation Mode.”  When enabled and supplied with your own OpenAI API key, the tutor will switch from scripted scenarios to open‑ended dialogue.  The app still enforces concise spoken replies, corrects conjugation mistakes, and respects your chosen dialect.  The OpenAI key is stored locally and is never transmitted to any server except the OpenAI API endpoint.  If you choose not to enable this mode the app remains fully functional using the built‑in scenarios.

## Local Development

VoiceTutor is built with [Vite](https://vitejs.dev/), [React](https://react.dev/) and [TypeScript](https://www.typescriptlang.org/).  It uses [Tailwind CSS](https://tailwindcss.com/) for styling and the [vite-plugin-pwa](https://vite-pwa-org.netlify.app/) to generate the manifest and service worker.  To work with the project locally you need Node JS ≥ 18.

1. **Install dependencies:**

   ```bash
   npm install
   ```

2. **Run a development server:**

   ```bash
   npm run dev
   ```

   This will start the app at <http://localhost:5173>.  Changes in `src/` are hot‑reloaded.

3. **Build for production:**

   ```bash
   npm run build
   ```

   The compiled assets will be placed in the `dist/` folder.  You can preview the production build with:

   ```bash
   npm run preview
   ```

## Deployment

VoiceTutor is designed to run on any static hosting platform, such as GitHub Pages or Cloudflare Pages.  After running `npm run build`, copy the contents of the `dist/` folder to your hosting service.  Because the project contains a service worker and manifest, hosting at the root of a domain or sub‑path will allow the app to be installed on mobile devices.

### Deploying to GitHub Pages

1. Commit the repository to GitHub.
2. In your repository settings, enable GitHub Pages and set the branch to `gh‑pages` (or `main`) and the folder to `/dist`.
3. Push the `dist/` contents on the specified branch.  GitHub will serve the site at `https://<username>.github.io/<repo>/`.

### Deploying to Cloudflare Pages

1. Create a new project in Cloudflare Pages and connect your GitHub repository.
2. Set the build command to `npm run build` and the build directory to `dist`.
3. Cloudflare Pages will build and deploy the project automatically.

## Browser Compatibility

The Web Speech API is supported in most modern browsers; however, exact support varies by platform.  Chrome, Edge and Safari on desktop and Android generally provide both speech recognition and synthesis.  On iOS, Safari supports `SpeechSynthesis` but not `SpeechRecognition`; as a result, speech recognition will fall back to displaying a message instructing the user to try a different browser.  The MDN reference provides detailed compatibility information and notes that speech synthesis and recognition are accessed via `window.speechSynthesis` and `SpeechRecognition`【290950699775772†L174-L205】.

VoiceTutor will attempt to enumerate all device voices and select the most appropriate match for the chosen dialect.  If no suitable voice is found you may need to install enhanced voices on your operating system.  For example, on macOS open **System Settings → Accessibility → Spoken Content → System Voice** and download additional Spanish voices.  On Windows open **Settings → Time & language → Speech** and add Spanish voices.  On iOS open **Settings → Accessibility → Spoken Content → Voices**.

## Voice Quality Guidance

Different devices and operating systems provide different quality of text‑to‑speech voices.  To get the most realistic experience:

* **Install enhanced voices.**  Many platforms offer high‑quality voices that can be downloaded for free.  See the steps above.
* **Adjust the speech rate.**  The settings menu in VoiceTutor allows you to adjust the speech rate.  Slowing down the speech can make it easier to follow along when you are starting out.
* **Use headphones.**  Headphones help isolate the tutor’s voice from ambient noise and make it easier for your microphone to pick up your responses.

## Optional ChatGPT Mode

To enable Open Conversation Mode, click the settings icon and paste your OpenAI API key.  When enabled the app will send your conversation history to the OpenAI Chat Completion API to generate responses.  The key is stored locally and never transmitted anywhere else.  If no key is provided the app will use its built‑in scenarios and fuzzy‑matching logic.

## Contributing

This project was generated automatically for demonstration purposes.  Feel free to fork it and expand the conversation scenarios, add additional languages, or improve the skill detection heuristics.  Contributions are welcome!