import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

// https://vitejs.dev/config/
export default defineConfig({
  // Deploy under the GitHub Pages sub-path
  base: '/voice-tutor/',
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      injectRegister: 'auto',
      includeAssets: [
        // These assets will be copied as-is to the dist folder
        'icons/icon-192.png',
        'icons/icon-512.png'
      ],
      manifest: {
        name: 'Voice Tutor',
        short_name: 'VoiceTutor',
        description: 'Practice languages with voice conversation.',
        theme_color: '#ffffff',
        background_color: '#ffffff',
        display: 'standalone',
        scope: '/voice-tutor/',
        start_url: '/voice-tutor/',
        icons: [
          {
            src: 'icons/icon-192.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: 'icons/icon-512.png',
            sizes: '512x512',
            type: 'image/png'
          }
        ]
      },
      workbox: {
        cleanupOutdatedCaches: true
      }
    })
  ]
});