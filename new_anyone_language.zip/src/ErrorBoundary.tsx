import React, { ErrorInfo, ReactNode } from 'react';

interface Props {
  /** Elements that this boundary should render when no error has occurred. */
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: any;
}

/**
 * A simple React error boundary that catches JavaScript errors anywhere in its
 * child component tree. When an error occurs a fallback UI is displayed
 * instead of the blank white screen typical of unhandled errors. The
 * component logs errors to the console for debugging.
 */
class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: any): State {
    // Update state to indicate an error has occurred.
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: ErrorInfo) {
    // You can also log the error to an external service here.
    // For now we just log to the console.
    console.error('ErrorBoundary caught an error', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // Render a user-friendly fallback UI.
      return (
        <div style={{ padding: '1rem' }}>
          <h1>Something went wrong.</h1>
          {this.state.error && (
            <p style={{ whiteSpace: 'pre-wrap' }}>{String(this.state.error)}</p>
          )}
          <p>Please try reloading the page.</p>
          <button
            style={{ padding: '0.5rem 1rem', marginTop: '1rem' }}
            onClick={() => window.location.reload()}
          >
            Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;