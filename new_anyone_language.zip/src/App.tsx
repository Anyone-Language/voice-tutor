import React, { useState, useEffect, useRef } from 'react';

/**
 * A language option consists of a display label and a locale string. The locale
 * is used both for speech synthesis and speech recognition.
 */
interface LanguageOption {
  label: string;
  locale: string;
}

/**
 * A scenario consists of a title and a list of prompts. In the future you
 * could expand this to include expected answers for more intelligent
 * evaluation, but for now we simply cycle through prompts and listen for
 * responses.
 */
interface Scenario {
  title: string;
  prompts: string[];
}

// Comprehensive list of supported languages and locales. If a locale isn't
// recognised by the Web Speech API, the app will gracefully fall back to a
// related language or the first available voice.
const LANGUAGES: LanguageOption[] = [
  { label: 'Afrikaans (South Africa)', locale: 'af-ZA' },
  { label: 'Arabic (Saudi Arabia)', locale: 'ar-SA' },
  { label: 'Bengali (Bangladesh)', locale: 'bn-BD' },
  { label: 'Cantonese (Hong Kong)', locale: 'zh-HK' },
  { label: 'Chinese, Mandarin (China)', locale: 'zh-CN' },
  { label: 'Chinese, Mandarin (Taiwan)', locale: 'zh-TW' },
  { label: 'Czech (Czech Republic)', locale: 'cs-CZ' },
  { label: 'Danish (Denmark)', locale: 'da-DK' },
  { label: 'Dutch (Netherlands)', locale: 'nl-NL' },
  { label: 'English (United States)', locale: 'en-US' },
  { label: 'English (United Kingdom)', locale: 'en-GB' },
  { label: 'English (Australia)', locale: 'en-AU' },
  { label: 'Filipino (Philippines)', locale: 'fil-PH' },
  { label: 'Finnish (Finland)', locale: 'fi-FI' },
  { label: 'French (France)', locale: 'fr-FR' },
  { label: 'French (Canada)', locale: 'fr-CA' },
  { label: 'German (Germany)', locale: 'de-DE' },
  { label: 'Greek (Greece)', locale: 'el-GR' },
  { label: 'Gujarati (India)', locale: 'gu-IN' },
  { label: 'Hebrew (Israel)', locale: 'he-IL' },
  { label: 'Hindi (India)', locale: 'hi-IN' },
  { label: 'Hungarian (Hungary)', locale: 'hu-HU' },
  { label: 'Indonesian (Indonesia)', locale: 'id-ID' },
  { label: 'Italian (Italy)', locale: 'it-IT' },
  { label: 'Japanese (Japan)', locale: 'ja-JP' },
  { label: 'Kannada (India)', locale: 'kn-IN' },
  { label: 'Korean (Korea)', locale: 'ko-KR' },
  { label: 'Malay (Malaysia)', locale: 'ms-MY' },
  { label: 'Malayalam (India)', locale: 'ml-IN' },
  { label: 'Marathi (India)', locale: 'mr-IN' },
  { label: 'Norwegian (Norway)', locale: 'nb-NO' },
  { label: 'Polish (Poland)', locale: 'pl-PL' },
  { label: 'Portuguese (Brazil)', locale: 'pt-BR' },
  { label: 'Portuguese (Portugal)', locale: 'pt-PT' },
  { label: 'Punjabi (India)', locale: 'pa-IN' },
  { label: 'Romanian (Romania)', locale: 'ro-RO' },
  { label: 'Russian (Russia)', locale: 'ru-RU' },
  { label: 'Slovak (Slovakia)', locale: 'sk-SK' },
  { label: 'Spanish (Spain)', locale: 'es-ES' },
  { label: 'Spanish (Mexico)', locale: 'es-MX' },
  { label: 'Swahili (Tanzania)', locale: 'sw-TZ' },
  { label: 'Swedish (Sweden)', locale: 'sv-SE' },
  { label: 'Tamil (India)', locale: 'ta-IN' },
  { label: 'Telugu (India)', locale: 'te-IN' },
  { label: 'Thai (Thailand)', locale: 'th-TH' },
  { label: 'Turkish (Turkey)', locale: 'tr-TR' },
  { label: 'Ukrainian (Ukraine)', locale: 'uk-UA' },
  { label: 'Urdu (Pakistan)', locale: 'ur-PK' },
  { label: 'Vietnamese (Vietnam)', locale: 'vi-VN' },
  { label: 'Zulu (South Africa)', locale: 'zu-ZA' }
];

// A handful of placement prompts used to loosely gauge the learner's level.
const placementPrompts: string[] = [
  'Say “hello” in your language.',
  'How do you say “thank you”?',
  'Count from one to five.',
  'Say the days of the week.',
  'Describe your favourite colour.'
];

// A selection of scenarios covering common situations. More prompts can be
// added later to extend the curriculum.
const scenarios: Scenario[] = [
  {
    title: 'Greetings',
    prompts: [
      'Hi! How are you?',
      'What is your name?',
      'It is nice to meet you.'
    ]
  },
  {
    title: 'Ordering Food',
    prompts: [
      'I would like to order a coffee.',
      'Do you have a vegetarian option?',
      'Could I have the bill, please?'
    ]
  },
  {
    title: 'Travel',
    prompts: [
      'Where is the train station?',
      'How much is a ticket to the airport?',
      'What time does the bus leave?'
    ]
  },
  {
    title: 'Small Talk',
    prompts: [
      'What do you do for a living?',
      'Do you have any hobbies?',
      'What is your favourite book?'
    ]
  },
  {
    title: 'Emergencies',
    prompts: [
      'I need help!',
      'Call the police!',
      'I am sick.'
    ]
  }
];

// Generic prompts used for free talk mode.
const freeTalkPrompts: string[] = [
  'Tell me about your day.',
  'Describe your favourite food.',
  'What are your plans for the weekend?',
  'What do you enjoy doing in your free time?',
  'Tell me about a memorable trip you have taken.'
];

/**
 * Retrieve a speech synthesis voice for the given locale. If an exact locale
 * match is not found, the function attempts to find a voice that matches
 * the base language (e.g. en for en-GB). If no match can be found, the
 * default voice is returned. When voices are not yet loaded this function
 * returns null; callers should handle that case gracefully.
 */
function getVoiceForLocale(
  voices: SpeechSynthesisVoice[] | undefined,
  locale: string,
): SpeechSynthesisVoice | null {
  if (!voices || voices.length === 0) return null;
  // Try exact match
  let match = voices.find((v) => v.lang === locale);
  if (match) return match;
  // Try base language
  const base = locale.split('-')[0];
  match = voices.find((v) => v.lang.startsWith(base));
  if (match) return match;
  return voices[0];
}

/**
 * Main application component. Handles selection of languages, scenario
 * progression, speech synthesis/recognition and basic settings.
 */
const App: React.FC = () => {
  // Selected language option. Persist to localStorage so the app remembers
  // between sessions.
  const [language, setLanguage] = useState<LanguageOption>(() => {
    const stored = localStorage.getItem('vt_language');
    if (stored) {
      const parsed = LANGUAGES.find((l) => l.locale === stored);
      if (parsed) return parsed;
    }
    return LANGUAGES[0];
  });

  // Whether to show transcripts. Persist this preference.
  const [showTranscript, setShowTranscript] = useState<boolean>(() => {
    const stored = localStorage.getItem('vt_showTranscript');
    return stored ? stored === 'true' : false;
  });

  // Speech rate for the tutor voice. Persist to localStorage.
  const [speechRate, setSpeechRate] = useState<number>(() => {
    const stored = localStorage.getItem('vt_speechRate');
    return stored ? parseFloat(stored) : 1.0;
  });

  // A simple proficiency score from 0 to 100. It increases slightly after
  // each completed prompt to simulate progress.
  const [proficiency, setProficiency] = useState<number>(() => {
    const stored = localStorage.getItem('vt_proficiency');
    return stored ? parseFloat(stored) : 0;
  });

  // Current mode of the application: idle (no session), placement test,
  // lesson (scenario practice) or free talk.
  const [mode, setMode] = useState<'idle' | 'placement' | 'lesson' | 'free'>(
    'idle',
  );

  // Index of the current scenario when in lesson mode.
  const [currentScenarioIndex, setCurrentScenarioIndex] = useState<number>(0);

  // Index of the current prompt within the placement prompts or scenario.
  const [promptIndex, setPromptIndex] = useState<number>(0);

  // The prompt currently being asked. Displayed on screen for reference.
  const [currentPrompt, setCurrentPrompt] = useState<string>('');

  // Whether the app is waiting for the user to provide a spoken response.
  const [awaitingResponse, setAwaitingResponse] = useState<boolean>(false);

  // Whether speech recognition is currently listening. Controls the mic button
  // appearance.
  const [listening, setListening] = useState<boolean>(false);

  // Transcript history of user responses for the session. When showTranscript
  // is enabled this history is displayed to the user.
  const [transcripts, setTranscripts] = useState<string[]>([]);

  // Store loaded voices to avoid repeatedly querying the speech synthesis API.
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  // Reference to the speech recognition instance so it can be started/stopped.
  const recognitionRef = useRef<any>(null);

  // Load voices when the component mounts and whenever the voices change (the
  // voices list may update asynchronously in some browsers).
  useEffect(() => {
    function updateVoices() {
      const list = window.speechSynthesis.getVoices();
      setVoices(list);
    }
    updateVoices();
    window.speechSynthesis.onvoiceschanged = updateVoices;
  }, []);

  // Persist language selection, transcript visibility, speech rate and
  // proficiency to localStorage whenever they change.
  useEffect(() => {
    localStorage.setItem('vt_language', language.locale);
  }, [language]);
  useEffect(() => {
    localStorage.setItem('vt_showTranscript', showTranscript.toString());
  }, [showTranscript]);
  useEffect(() => {
    localStorage.setItem('vt_speechRate', speechRate.toString());
  }, [speechRate]);
  useEffect(() => {
    localStorage.setItem('vt_proficiency', proficiency.toString());
  }, [proficiency]);

  /**
   * Speak some text in the selected language using the browser's Speech
   * Synthesis API. Falls back to the default voice if an exact locale match
   * cannot be found. The rate is taken from the speechRate state. Errors
   * encountered are logged to the console. Speech synthesis is skipped on
   * servers or environments without the API.
   */
  const speak = (text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    const voice = getVoiceForLocale(voices, language.locale);
    const utter = new SpeechSynthesisUtterance(text);
    if (voice) utter.voice = voice;
    utter.rate = speechRate;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utter);
  };

  /**
   * Helper to create or return a SpeechRecognition instance. This function
   * constructs the correct recognition class for the current browser. It
   * attaches result and error handlers to update state accordingly.
   */
  const getRecognition = () => {
    if (recognitionRef.current) return recognitionRef.current;
    const SpeechRecognition: any =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn('Speech recognition is not supported in this browser');
      return null;
    }
    const recog = new SpeechRecognition();
    recog.continuous = false;
    recog.interimResults = false;
    recog.maxAlternatives = 1;
    recog.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      handleUserResponse(transcript);
    };
    recog.onerror = (event: any) => {
      console.error('Speech recognition error', event.error);
      setListening(false);
      setAwaitingResponse(false);
    };
    recog.onend = () => {
      setListening(false);
    };
    recognitionRef.current = recog;
    return recog;
  };

  /**
   * Start listening for the user's spoken response. This should only be
   * invoked when awaitingResponse is true. If speech recognition isn't
   * supported the function will simply log a warning.
   */
  const startListening = () => {
    const recog = getRecognition();
    if (!recog) return;
    try {
      recog.lang = language.locale;
      recog.start();
      setListening(true);
    } catch (err) {
      console.error('Failed to start recognition', err);
    }
  };

  /**
   * Stop listening. Useful when the user toggles the mic button or moves to
   * the next prompt early. If the recognition instance isn't created this
   * function does nothing.
   */
  const stopListening = () => {
    const recog = recognitionRef.current;
    if (recog) {
      try {
        recog.stop();
      } catch (err) {
        // ignore errors caused by stopping when not started
      }
    }
    setListening(false);
  };

  /**
   * When the user has spoken a response this handler updates the transcript
   * history, increments the proficiency and moves on to the next prompt or
   * scenario depending on the current mode. It also stops the listening
   * session and resets awaitingResponse.
   */
  const handleUserResponse = (response: string) => {
    setTranscripts((prev) => [...prev, response]);
    // Increase proficiency gradually. Cap at 100.
    setProficiency((prev) => Math.min(100, prev + 5));
    setAwaitingResponse(false);
    // Advance to the next prompt after a short delay to allow the user to read
    // any spoken feedback.
    setTimeout(() => {
      nextPrompt();
    }, 500);
  };

  /**
   * Determine and speak the next prompt based on the current mode and
   * position. When the placement test completes the mode switches to lesson.
   * When all scenarios are completed the app moves to free talk mode.
   */
  const nextPrompt = () => {
    if (mode === 'placement') {
      const nextIndex = promptIndex + 1;
      if (nextIndex < placementPrompts.length) {
        setPromptIndex(nextIndex);
        const p = placementPrompts[nextIndex];
        setCurrentPrompt(p);
        speak(p);
        setAwaitingResponse(true);
      } else {
        // Placement complete. Start lesson mode.
        setMode('lesson');
        setPromptIndex(0);
        setCurrentScenarioIndex(0);
        const first = scenarios[0].prompts[0];
        setCurrentPrompt(first);
        speak(first);
        setAwaitingResponse(true);
      }
    } else if (mode === 'lesson') {
      const scenario = scenarios[currentScenarioIndex];
      const nextIndex = promptIndex + 1;
      if (nextIndex < scenario.prompts.length) {
        setPromptIndex(nextIndex);
        const p = scenario.prompts[nextIndex];
        setCurrentPrompt(p);
        speak(p);
        setAwaitingResponse(true);
      } else {
        // Move to the next scenario or free talk if finished.
        const nextScenario = currentScenarioIndex + 1;
        if (nextScenario < scenarios.length) {
          setCurrentScenarioIndex(nextScenario);
          setPromptIndex(0);
          const p = scenarios[nextScenario].prompts[0];
          setCurrentPrompt(p);
          speak(p);
          setAwaitingResponse(true);
        } else {
          // Completed all scenarios – enter free talk.
          setMode('free');
          setPromptIndex(0);
          const p = freeTalkPrompts[0];
          setCurrentPrompt(p);
          speak(p);
          setAwaitingResponse(true);
        }
      }
    } else if (mode === 'free') {
      // In free talk we cycle through prompts indefinitely.
      const nextIndex = promptIndex + 1;
      if (nextIndex < freeTalkPrompts.length) {
        setPromptIndex(nextIndex);
        const p = freeTalkPrompts[nextIndex];
        setCurrentPrompt(p);
        speak(p);
        setAwaitingResponse(true);
      } else {
        setPromptIndex(0);
        const p = freeTalkPrompts[0];
        setCurrentPrompt(p);
        speak(p);
        setAwaitingResponse(true);
      }
    }
  };

  /**
   * Begin the placement test. Resets transcripts and proficiency only if
   * starting fresh. A placement test always starts at the first prompt.
   */
  const startPlacement = () => {
    stopListening();
    setMode('placement');
    setPromptIndex(0);
    setTranscripts([]);
    // Do not reset proficiency here – learners may continue building on
    // previous sessions.
    const p = placementPrompts[0];
    setCurrentPrompt(p);
    speak(p);
    setAwaitingResponse(true);
  };

  /**
   * Begin the lesson mode from the first scenario. Use this when the user
   * wants to skip the placement test.
   */
  const startLesson = () => {
    stopListening();
    setMode('lesson');
    setPromptIndex(0);
    setCurrentScenarioIndex(0);
    setTranscripts([]);
    const p = scenarios[0].prompts[0];
    setCurrentPrompt(p);
    speak(p);
    setAwaitingResponse(true);
  };

  /**
   * Start free talk mode immediately. Useful for advanced learners who just
   * want to practise conversation topics without structured guidance.
   */
  const startFreeTalk = () => {
    stopListening();
    setMode('free');
    setPromptIndex(0);
    setTranscripts([]);
    const p = freeTalkPrompts[0];
    setCurrentPrompt(p);
    speak(p);
    setAwaitingResponse(true);
  };

  /**
   * Reset all progress and settings to their defaults. This function clears
   * localStorage keys and state variables. It does not reload the page.
   */
  const resetProgress = () => {
    stopListening();
    localStorage.removeItem('vt_language');
    localStorage.removeItem('vt_showTranscript');
    localStorage.removeItem('vt_speechRate');
    localStorage.removeItem('vt_proficiency');
    setLanguage(LANGUAGES[0]);
    setShowTranscript(false);
    setSpeechRate(1.0);
    setProficiency(0);
    setMode('idle');
    setPromptIndex(0);
    setCurrentScenarioIndex(0);
    setCurrentPrompt('');
    setTranscripts([]);
    setAwaitingResponse(false);
  };

  /**
   * Handler for the mic button. Starts or stops listening depending on
   * whether the app is currently awaiting a response. If not awaiting a
   * response the current prompt is repeated.
   */
  const handleMicClick = () => {
    if (listening) {
      stopListening();
    } else {
      if (awaitingResponse) {
        startListening();
      } else if (currentPrompt) {
        // Repeat the prompt if the learner wants to hear it again.
        speak(currentPrompt);
        setAwaitingResponse(true);
      }
    }
  };

  // Derived state: label for the mic button based on listening status.
  const micLabel = listening ? '◼︎' : '🎤';

  return (
    <div className="container">
      <h1>Voice Tutor</h1>
      <div className="controls">
        <label>
          Language:
          <select
            className="select"
            value={language.locale}
            onChange={(e) => {
              const selected = LANGUAGES.find(
                (l) => l.locale === e.target.value,
              );
              if (selected) setLanguage(selected);
            }}
          >
            {LANGUAGES.map((lang) => (
              <option key={lang.locale} value={lang.locale}>
                {lang.label}
              </option>
            ))}
          </select>
        </label>
        <label>
          Show Transcript:
          <input
            type="checkbox"
            checked={showTranscript}
            onChange={(e) => setShowTranscript(e.target.checked)}
          />
        </label>
        <label>
          Speech Rate: {speechRate.toFixed(1)}
          <input
            type="range"
            min="0.5"
            max="2.0"
            step="0.1"
            value={speechRate}
            onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
          />
        </label>
      </div>
      <div className="controls">
        {mode !== 'placement' && (
          <button onClick={startPlacement}>Placement Test</button>
        )}
        {mode !== 'lesson' && (
          <button onClick={startLesson}>Start Lesson</button>
        )}
        {mode !== 'free' && <button onClick={startFreeTalk}>Free Talk</button>}
        <button onClick={resetProgress}>Reset</button>
      </div>
      <div className="controls">
        <span>Proficiency: {proficiency.toFixed(0)}%</span>
      </div>
      {currentPrompt && (
        <div className="prompt">{currentPrompt}</div>
      )}
      <button
        className={`mic-button${listening ? ' listening' : ''}`}
        onClick={handleMicClick}
        title={listening ? 'Stop listening' : 'Start listening'}
      >
        {micLabel}
      </button>
      {showTranscript && transcripts.length > 0 && (
        <div className="transcript">
          <h3>Transcript</h3>
          <ul style={{ listStyle: 'none', paddingLeft: 0 }}>
            {transcripts.map((t, idx) => (
              <li key={idx}>{t}</li>
            ))}
          </ul>
        </div>
      )}
      {/* When not in a session display a welcome message */}
      {mode === 'idle' && (
        <p>
          Welcome to Voice Tutor! Select a language and start a placement test,
          lesson or free talk to practise your speaking skills. Click the mic
          button when prompted to answer questions aloud.
        </p>
      )}
    </div>
  );
};

export default App;